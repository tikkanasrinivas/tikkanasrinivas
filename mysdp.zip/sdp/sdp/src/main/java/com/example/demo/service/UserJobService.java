package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.company.CreateBatch;
import com.example.demo.repository.CreateBatchRepository;
import com.example.demo.repository.JobApplicationRepository;

@Service
public class UserJobService {
	
	@Autowired
	private CreateBatchRepository cbRepo;
	
	
	
	
	@Autowired
	private JobApplicationRepository jar;

	
	public CreateBatch Details(long id) {
		CreateBatch x=cbRepo.findById(id);
		return x;
	}


	public CreateBatch lessCount(long id) {
		CreateBatch x=cbRepo.findById(id);
		return x;
		
	}
	
	

//	public boolean getconfirm(long id) {
//		System.out.println(id);
//		
//		long x=jar.findBycbid(id);
//		if(x>0)
//			return false;
//		return true;
//	}

}
